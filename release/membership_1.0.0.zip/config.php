<?php 

return [
	'module_path' => 'module/Membership',
    'layout_path' => 'layout/membership'
];
