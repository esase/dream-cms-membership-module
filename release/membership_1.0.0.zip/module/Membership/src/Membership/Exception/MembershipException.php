<?php

namespace Membership\Exception;
use Exception;

class MembershipException extends Exception
{}