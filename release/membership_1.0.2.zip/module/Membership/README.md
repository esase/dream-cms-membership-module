# Membership
Membership module for Dream CMS. Module allows to purchase different roles on the site.
