DROP TABLE IF EXISTS `membership_level_connection`;
DROP TABLE IF EXISTS `membership_level`;
